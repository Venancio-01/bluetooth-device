#!/bin/bash
set -e
INSTALL_DIR="/opt/bluetooth-device"
echo "安装蓝牙设备服务到 Orange Pi..."
sudo mkdir -p "$INSTALL_DIR"
sudo cp bluetooth-device "$INSTALL_DIR/"
sudo cp start.sh "$INSTALL_DIR/"
sudo chmod +x "$INSTALL_DIR/bluetooth-device"
sudo chmod +x "$INSTALL_DIR/start.sh"
echo "安装完成！运行: cd $INSTALL_DIR && ./start.sh"
