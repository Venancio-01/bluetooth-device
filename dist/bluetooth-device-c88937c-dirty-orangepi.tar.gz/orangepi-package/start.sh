#!/bin/bash
# Orange Pi 蓝牙设备服务启动脚本

# 检查串口权限
if [ ! -r /dev/ttyUSB0 ]; then
    echo "警告: 无法访问 /dev/ttyUSB0，请检查设备连接和权限"
    echo "可以尝试: sudo chmod 666 /dev/ttyUSB0"
fi

echo "启动蓝牙设备服务..."
./bluetooth-device
