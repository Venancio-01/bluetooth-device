#!/bin/bash
# Orange Pi 安装脚本

set -e

INSTALL_DIR="/opt/bluetooth-device"
SERVICE_FILE="/etc/systemd/system/bluetooth-device.service"

echo "安装蓝牙设备服务到 Orange Pi..."

# 创建安装目录
sudo mkdir -p "$INSTALL_DIR"

# 复制文件
sudo cp bluetooth-device "$INSTALL_DIR/"
sudo cp start.sh "$INSTALL_DIR/"
sudo cp -r docs "$INSTALL_DIR/"
sudo cp README.md "$INSTALL_DIR/"

# 设置权限
sudo chmod +x "$INSTALL_DIR/bluetooth-device"
sudo chmod +x "$INSTALL_DIR/start.sh"
sudo chown -R pi:pi "$INSTALL_DIR"

# 安装系统服务
sudo cp bluetooth-device.service "$SERVICE_FILE"
sudo systemctl daemon-reload

echo "安装完成！"
echo ""
echo "使用方法:"
echo "  启动服务: sudo systemctl start bluetooth-device"
echo "  开机自启: sudo systemctl enable bluetooth-device"
echo "  查看状态: sudo systemctl status bluetooth-device"
echo "  查看日志: sudo journalctl -u bluetooth-device -f"
echo ""
echo "手动运行: cd $INSTALL_DIR && ./start.sh"
