#!/bin/bash
# Orange Pi 蓝牙设备服务启动脚本

# 检查串口权限
if [ ! -r /dev/ttyUSB0 ]; then
    echo "警告: 无法访问 /dev/ttyUSB0，请检查设备连接和权限"
    echo "可以尝试: sudo chmod 666 /dev/ttyUSB0"
    echo "或添加用户到 dialout 组: sudo usermod -a -G dialout $USER"
fi

# 设置环境变量
export GOMAXPROCS=$(nproc)

# 启动服务
echo "启动蓝牙设备服务..."
./bluetooth-device
